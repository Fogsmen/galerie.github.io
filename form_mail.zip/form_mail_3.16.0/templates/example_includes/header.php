


  <h3 style="border:1px dashed #FF5F00;padding:10px;">
    Welcome - Today is the <?php echo date("Y-m-d", mktime()); ?>.
  </h3>